<?php
 include('../db/koneksi.php');
 $foto_id = $_GET['foto_id'];
 $user_id = $_GET['user_id'];
 $tanggal = date('Y-m-d');
 
 $query = mysqli_query($koneksi, 
 "INSERT INTO tb_like 
 (`foto_id`, `user_id`, `tanggal_like`) 
 VALUES ('$foto_id', '$user_id','$tanggal')"
 );
 if($query){
 echo "<script>
 alert('Makasii udah suka :)');
 window.location.href='../lihat_foto.php?id=$foto_id';
 </script>";
 } else {
 die("Error: " . mysqli_error($koneksi));
 }
?>