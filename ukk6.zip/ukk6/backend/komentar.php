<?php
 include('../db/koneksi.php');
 $foto_id = $_GET['foto_id'];
 $user_id = $_GET['user_id'];
 $tanggal = date('Y-m-d');
 $komentar = $_POST['komentar'];
 
 $query = mysqli_query($koneksi,  "INSERT INTO tb_komentarfoto 
 (`foto_id`, `user_id`, `isi_komentar`, `tanggal_komentar`) 
 VALUES ('$foto_id', '$user_id','$komentar','$tanggal')"
 );
 if($query){
 echo "<script>
 alert('wiwww, Komentar berhasil ditambahkan :)');
 window.location.href='../lihat_foto.php?id=$foto_id';
 </script>";
 } else {
 die("Error: " . mysqli_error($koneksi));
 }
?>