<?php
 include('../db/koneksi.php');
 $name = $_POST['albumName'];
 $deskripsi = $_POST['description'];
 $tanggal = date('Y-m-d');
 $user_id = $_POST['user_id'];
 $id = $_POST['album_id'];
 $query = mysqli_query($koneksi, "UPDATE tb_album SET nama_album='$name', deskripsi='$deskripsi' WHERE album_id='$id'");
 if($query){
 echo "<script>
 window.location.href='../index1.php';
 </script>";
 } else {
 die("Error: " . mysqli_error($koneksi));
 }
?>