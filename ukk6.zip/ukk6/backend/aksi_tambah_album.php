<?php
	 include('../db/koneksi.php');
	 $name = $_POST['albumName'];
	 $deskripsi = $_POST['description'];
	 $tanggal = date('Y-m-d');
	 $user_id = $_POST['user_id'];
	 $query = mysqli_query($koneksi, "INSERT INTO tb_album (`nama_album`, `deskripsi`, `tanggal_dibuat`, `user_id`) VALUES ('$name', '$deskripsi','$tanggal','$user_id')"
	 );
	 if($query){
	 echo "<script>
	 alert('Album berhasil ditambahkan');
	 window.location.href='../index1.php';
	 </script>";
	 } else {
	 die("Error: " . mysqli_error($koneksi));
	 }
?>