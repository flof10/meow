
<?php
 include('../db/koneksi.php');
 $id = $_GET['id'];
 $query = mysqli_query($koneksi, "DELETE FROM tb_album WHERE album_id='$id'");
 // echo $id;
 if($query){
 echo "<script>
 alert('Album dihapus');
 window.location.href='../index1.php';
 </script>";
 } else {
 die("Error: " . mysqli_error($koneksi));
 }
?>