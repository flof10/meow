
<?php
 include('../db/koneksi.php');
 $name = $_POST['name'];
 $deskripsi = $_POST['description'];
 $tanggal = date('Y-m-d');
 $user_id = $_POST['user_id'];
 $album_id = $_POST['album_id'];
 // menupulasi pengambilan foto 
 $rand = rand();
 $ekstensi = array('png','jpg','jpeg','gif', 'webp');
 $filename = $_FILES['foto']['name'];
 $ukuran = $_FILES['foto']['size'];
 $ext = pathinfo($filename, PATHINFO_EXTENSION);
 if(!in_array($ext,$ekstensi) ) {
 // logika jika extensi yang diupload bukan foto(jpg, png, jpeg, gif )
 echo "<script>
 alert('Maaf,Sepertinya ini bukan foto');
 window.location.href='../tambah_foto.php';
 </script>";
 }else{
 if($ukuran < 10440700){
 // jika ukurannya tidak lebih dari 1MB 
 $namafotobaru = $rand.'_'.$filename;
 move_uploaded_file($_FILES['foto']['tmp_name'], '../gambar/'.$rand.'_'.$filename);
 $lokasi_foto = 'gambar/'.$namafotobaru;
 $query = mysqli_query($koneksi, "INSERT INTO tb_foto (`judul_foto`, `deskripsi_foto`, `tanggal_unggah`,`lokasi_file`, `album_id`, `user_id`) VALUES ('$name', '$deskripsi','$tanggal','$lokasi_foto', '$album_id', '$user_id')"
 );
 if($query){
 echo "<script>
 alert('Foto berhasil ditambahkan');
 window.location.href='../index1.php';
 </script>";
 } else {
 die("Error: " . mysqli_error($koneksi));
 }
 }else{
 // jika ukuran foto lebih dari 1MM 
 echo "<script>
 alert('Maaf,Ukuran foto terlalu besar');
 window.location.href='../tambah_foto.php';
 </script>";
 }
 }
?>