<!DOCTYPE html>
<html lang="en">
<!-- coding by helpme_coder -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="polaroid-camera">
        <button id="button"><a href="auth/login.php">masuk</a></button>
        <div id="circle"></div>
        <div class="lens">
            <div class="reflection"></div>
        </div>
        <div class="flash"></div>
        <div class="stripes"></div>
        <div class="bottom">
            <div class="bottom-front"></div>
        </div>
        <div class="slot"></div>
        <div class="shadow"></div>
        <div id="photo" class="photo">
            <div class="house">
                <div class="windows">
                </div>
                </div>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>

</html>
