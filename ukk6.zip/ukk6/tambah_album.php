<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Gallery</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fontawesome/5.15.1/css/all.min.css" />
        <!-- Memasukkan Font Awesome untuk ikon -->
        <link rel="stylesheet" href="style/index.css" />
    </head>
    <body>
        <?php
include 'inc/Header.php'
?>
        <!-- jika terdeteksi get id -->
        <?php
$id = isset($_GET['id']) ? $_GET['id'] : ''; //dibaca $_GET['id'] atau null
if ($id) {
    $queryalbum = mysqli_query($koneksi, "SELECT * FROM tb_album WHERE album_id = '$id'");
    $album = mysqli_fetch_assoc($queryalbum);
    $action = "backend/aksi_update_album.php";
} else {
    $action = "backend/aksi_tambah_album.php";
}
?>
        <div class="content">
            <div class="form-container">
                <h2>Tambahkan Album</h2>
                <hr />
                <form action="<?php echo $action ?>" method="post">
                    <label for="albumName">Nama album :</label>
                    <input type="text" id="albumName" name="albumName" value="<?php echo isset($album['nama_album']) ? $album['nama_album'] : ''; ?>" required />
                    <label for="description">Keterangan :</label>
                    <textarea id="description" name="description" rows="4" required><?php echo isset($album['deskripsi']) ? $album['deskripsi'] : ''; ?></textarea>
                    <!-- ambil user id -->
                    <input type="hidden" name="user_id" value="<?php echo $user['user_id'] ?>" />
                    <input type="hidden" name="album_id" value="<?php echo $album['album_id'] ?>" />
                    <button type="submit">Simpan Album</button>
                </form>
            </div>
        </div>
    </body>
</html>
