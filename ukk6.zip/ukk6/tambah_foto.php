<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Gallery</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" />
        <!-- Memasukkan Font Awesome untuk ikon -->
        <link rel="stylesheet" href="style/index.css" />
    </head>
    <body>
        <?php
	 include('inc/Header.php')
	 ?>
        <!-- jika terdeteksi get id -->
        <?php
	 $id = isset($_GET['id']) ? $_GET['id'] : ''; //dibaca $_GET['id'] atau null
	 if($id){
	 $quedyeditfoto = mysqli_query($koneksi, "SELECT * FROM tb_foto WHERE foto_id='$id'");
	 $editfoto = mysqli_fetch_assoc($quedyeditfoto);
	 $action = "backend/aksi_update_foto.php";
	 } else {
	 $action = "backend/aksi_tambah_foto.php";
	 }
	 ?>
        <div class="content">
            <div class="form-container">
                <h2>Tambahkan Foto</h2>
                <hr />
                <form action="<?php echo $action ?>" method="post" enctype="multipart/form-data">
                    <label for="name">Judul Foto:</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value="<?php echo isset($editfoto['judul_foto']) ? $editfoto['judul_foto'] : ''; ?>"
                        required
                    />
                    <label for="description">Keterangan :</label>
                    <textarea id="description" name="description" rows="4" required><?php echo isset($editfoto['deskripsi_foto']) ? $editfoto['deskripsi_foto'] : ''; ?></textarea>
                    <label for="albumName">Album</label>
                    <select name="album_id" id="">
                        <option value="">- Pilih Album -</option>
                        <?php
							$querydata = mysqli_query($koneksi, "SELECT * from tb_album");
							while($dataalbum = mysqli_fetch_array($querydata))
							{
						?>
                        <option value="<?php echo $dataalbum['album_id'] ?>">
                            <?php echo $dataalbum['nama_album'] ?>
                        </option>
                        <?php
							}
						?>
                    </select>
                    <label for="foto">Pilih Foto:</label>
                    <input
                        type="file"
                        id="foto"
                        name="foto"
                        value="<?php echo isset($editfoto['nama_album']) ? $editfoto['nama_album'] : ''; ?>"
                    />
                    <!-- ambil user id -->
                    <input type="hidden" name="user_id" value="<?php echo $user['user_id'] ?>" />
                    <input type="hidden" name="foto_id" value="<?php echo $editfoto['foto_id'] ?>" />
                    <button type="submit">Simpan Album</button>
                </form>
            </div>
        </div>
    </body>
</html>