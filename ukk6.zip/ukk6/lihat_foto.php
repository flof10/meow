<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Album</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"> <!-- Memasukkan Font Awesome untuk ikon -->
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
	<link rel="stylesheet" href="style/index.css">
</head>

<body>
	<?php
	include('inc/header.php');
	$id = isset($_GET['id']) ? $_GET['id'] : '';
	$quedyeditfoto = mysqli_query($koneksi, "SELECT * FROM tb_foto WHERE foto_id='$id'");
	$datafoto = mysqli_fetch_assoc($quedyeditfoto);
	?>
	<div class="content-2">
		<div class="sidebar">
			<div class="sidebar-content-2">
				<img src="<?php echo isset($datafoto['lokasi_file']) ? $datafoto['lokasi_file'] : ''; ?>" alt="">
				<br>
				<br>
				Total Komentar :
				<!-- tampilkan jumlah komentar foto -->
				<?php
				$querykomentar = mysqli_query($koneksi, "SELECT COUNT(komentar_id) AS jml FROM 
			 tb_komentarfoto WHERE foto_id='$id'");
				$datakomentar = mysqli_fetch_assoc($querykomentar);
				?>
				<b><?php echo isset($datakomentar['jml']) ? $datakomentar['jml'] : 0; ?></b> <br>
				Total Like :
				<!-- tampilkan jumlah like foto -->
				<?php
				$querylike = mysqli_query($koneksi, "SELECT COUNT(like_id) AS jml FROM tb_like WHERE 
			 foto_id='$id'");
				$datalike = mysqli_fetch_assoc($querylike);
				?>
				<b><?php echo isset($datalike['jml']) ? $datalike['jml'] : 0; ?></b> <br> <br>
				<a href="backend/like.php?foto_id=<?php echo $id ?>&user_id=<?php echo $user['user_id'] ?>" class="btn">
					<i class="fa-regular fa-heart"></i>
				</a>
			</div>
		</div>
		<div class="photo-list-2">
			<div style="width: 100%;">
				<h1>
					<?php echo isset($datafoto['judul_foto']) ? $datafoto['judul_foto'] : ''; ?>
				</h1>
				<hr>
				<?php
				$user_id = isset($datafoto['user_id']) ? $datafoto['user_id'] : '';
				$querypembuat = mysqli_query($koneksi, "SELECT * FROM tb_foto, tb_user WHERE tb_foto.user_id='$user_id' and tb_user.user_id = '$user_id'");

				$datapembuat = mysqli_fetch_assoc($querypembuat);
				?>
				Dibuat Oleh : <b><?php echo isset($datapembuat['nama_lengkap']) ?
										$datapembuat['nama_lengkap'] : ''; ?></b> <br>
				Dibuat Tanggal : <b><?php echo isset($datafoto['tanggal_unggah']) ? $datafoto['tanggal_unggah'] : ''; ?></b> <br> <br>
				<b>Album :</b>
				<br>
				<?php
				$dataalbum = isset($datafoto['album_id']) ? $datafoto['album_id'] : '';
				$queryalbum = mysqli_query($koneksi, "SELECT * FROM tb_foto, tb_album WHERE 
			tb_foto.album_id='$dataalbum' and tb_album.album_id = '$dataalbum'");
				$dataalbum = mysqli_fetch_assoc($queryalbum);
				// menampilkan nama album 
				echo isset($dataalbum['nama_album']) ? $dataalbum['nama_album'] : '';
				?>
				<!-- menampilkan deskripsi album -->
				<br>
				<i>(<?php echo isset($dataalbum['deskripsi_foto']) ? $dataalbum['deskripsi_foto'] : ''; ?>)</i>
				<br>
				<br>
				<br>
				<b>Deskripsi Foto :</b>
				<br>
				<?php echo isset($datafoto['deskripsi_foto']) ? $datafoto['deskripsi_foto'] : ''; ?>
				<hr>
				<br>
				<br>
				<b>Komentar</b>
				<form action="backend/komentar.php?foto_id=<?php echo $id ?>&user_id=<?php echo
																						$user['user_id'] ?>" method="post">
					<textarea name="komentar" style="width: 100%; margin-top: 10px" id="" cols="30" rows="10" placeholder="Masukan komentar anda disini ..."></textarea>
					<button type="submit" class="btn-edit" style="margin-top: 8px; padding: 10px 
			20px">Komentari</button>
				</form>
				<div style="margin: 20px 0px 80px 0px;">
					<?php
					$qkomentar = mysqli_query($koneksi, "SELECT * FROM tb_komentarfoto WHERE foto_id ='$id' 
			 ORDER BY komentar_id DESC");
					while ($dkomentar = mysqli_fetch_array($qkomentar)) {
					?>
						<div class="komentar" style="margin-top: 20px; border-left: solid 3px blue; padding-left: 10px; 
border-radius: 8px">
							<!-- ambil data nama pengkomentar -->
							<?php
							$pengkomen = $dkomentar['user_id'];
							$querypengkomentar = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE user_id = 
'$pengkomen'");
							$datapengkomentar = mysqli_fetch_assoc($querypengkomentar);
							?>
							<b><?php echo isset($datapengkomentar['nama_lengkap']) ?
									$datapengkomentar['nama_lengkap'] : ''; ?> </b> | <?php echo isset($dkomentar['tanggal_komentar']) ?
																							$dkomentar['tanggal_komentar'] : ''; ?> <br>
							<span><?php echo isset($dkomentar['isi_komentar']) ? $dkomentar['isi_komentar'] : '';
									?></span>
						</div>
					<?php
					}
					?>
				</div>
			</div>
		</div>
	</div>

</html>