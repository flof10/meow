<?php
$queryfoto = mysqli_query($koneksi, "SELECT * from tb_foto,tb_album where tb_foto.album_id = tb_album.album_id ORDER BY tb_foto.foto_id DESC");
while ($datafoto = mysqli_fetch_array($queryfoto)) {
?>
	<div class="photo-card yu">
		<div class="relative">
			<a href="lihat_foto.php?id=<?php echo isset($datafoto['foto_id']) ? $datafoto['foto_id'] : ''; ?>">
				<img src="<?php echo isset($datafoto['lokasi_file']) ? $datafoto['lokasi_file'] : ''; ?>" alt="Photo 1">
			</a>
			<div class="absolute">
				<a href="tambah_foto.php?id=<?php echo isset($datafoto['foto_id']) ? $datafoto['foto_id'] : ''; ?>" class="btn-edit">edit</i></a>

				<a Onclick="return confirm('Yakin fotonya mau dihapus?')" href="backend/aksi_hapus_foto.php?id=<?php echo isset($datafoto['foto_id']) ? $datafoto['foto_id'] : ''; ?>" class="btn-hapus">hapus</a>

			</div>
		</div>
		<div class="details">
			<h3><?php echo isset($datafoto['judul_foto']) ? $datafoto['judul_foto'] : ''; ?></h3>
			<div class="meta">
				<span>
					<!-- ambil jumlah like -->
					<?php
					$foto_id = isset($datafoto['foto_id']) ? $datafoto['foto_id'] : '';
					$querylike = mysqli_query($koneksi, "SELECT COUNT(like_id) AS jml FROM tb_like WHERE foto_id='$foto_id'");
					$datalike = mysqli_fetch_assoc($querylike);
					?>
					<i class="fa fa-thumbs-up"></i> <?php echo isset($datalike['jml']) ? $datalike['jml'] : 0; ?> Likes
				</span>
				<span>
					<!-- ambil jumlah komentar -->
					<?php
					$querykomentar = mysqli_query($koneksi, "SELECT COUNT(komentar_id) AS jml FROM tb_komentarfoto WHERE foto_id='$foto_id'");
					$datakomentar = mysqli_fetch_assoc($querykomentar);
					?>
					<i class="fa fa-comments"></i> <?php echo isset($datakomentar['jml']) ? $datakomentar['jml'] : 0;
													?> Comments
				</span>
			</div> <br>
			<a href="lihat_foto.php?id=<?php echo isset($datafoto['foto_id']) ? $datafoto['foto_id'] : ''; ?>" class="btn">Lihat Detail</a>
		</div>
	</div>
<?php
}
?>