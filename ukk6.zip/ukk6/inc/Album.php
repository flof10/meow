<?php
 include('db/koneksi.php');
 $query = mysqli_query($koneksi, "SELECT * FROM tb_album, tb_user WHERE tb_album.user_id = tb_user.user_id ORDER BY tb_album.album_id desc");
 
 while($data = mysqli_fetch_array($query))
 {
?>
<a href="">
 <div class="album-list">
 <h3><?php echo $data['nama_album'] ?></h3>
 <p>Tanggal: <?php echo $data['tanggal_dibuat'] ?></p>
 <p>Pembuat: <?php echo $data['nama_lengkap'] ?></p>
 <?php
 if($data['user_id'] == $user['user_id']){
 ?>
 <a class="btn-edit" href="tambah_album.php?id=<?php echo $data['album_id'] ?>">Edit</a> | 
 <a class="btn-hapus"  Onclick="return confirm('Yakin nih dihapus?')" href="backend/aksi_hapus_album.php?id=<?php echo $data['album_id'] 
?> ">Hapus<i class="fa fa-trash"></i></a>
 <?php
 }
 ?>
 </div>
</a>
<?php
 }
?>