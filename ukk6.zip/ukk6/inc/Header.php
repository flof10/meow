<!-- cek apakah sudah login -->
<?php
session_start();
if ($_SESSION['status'] != "login") {
	header("location:auth/login.php?pesan=belum_login");
}

// ambil nama dari database 
include('db/koneksi.php');
$username = $_SESSION['username'];
$query = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username='$username'");
$user = mysqli_fetch_assoc($query);
?>
<div class="user-info" style="z-index: 13;">
	<a href="index1.php">
		<h1>Gallery</h1>
	</a>
	<div class="menu">
		<ul>
			<li class="active">
				<a href="index1.php" class="link">
					Beranda
				</a>
			</li>
			<li>
				<a href="tambah_album.php" class="link">
					Tambah Album
				</a>
			</li>
			<li>
				<a href="tambah_foto.php" class="link">
					Tambah Foto
				</a>
			</li>
			<li>
				<a href="backend/logout.php" class="link">- LOGOUT -</a>
			</li>
		</ul>
	</div>

	<div class="user">
		<!-- <img src="https://placekitten.com/30/30" class="avatar" alt="User Avatar"> -->
		<span>
			<b><?php echo "Hello " . $user['nama_lengkap'] ?></b>

		</span>
	</div>
</div>